﻿using System;
using System.Collections.Generic;
using System.Linq;
using AdeptusMechanicus.ExtensionMethods;
using Harmony;
using Verse;

namespace AdeptusMechanicus
{

    public class WraithPawn : ArtificalPawn
    {
        public override void ExposeData()
        {
            base.ExposeData();
        }

    }

}
