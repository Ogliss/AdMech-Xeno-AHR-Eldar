﻿using System;
using System.Collections.Generic;
using System.Linq;
using AdeptusMechanicus.ExtensionMethods;
using HarmonyLib;
using Verse;

namespace AdeptusMechanicus
{

    public class WraithPawn : ArtificalPawn
    {
        public override void ExposeData()
        {
            base.ExposeData();
        }

    }

}
